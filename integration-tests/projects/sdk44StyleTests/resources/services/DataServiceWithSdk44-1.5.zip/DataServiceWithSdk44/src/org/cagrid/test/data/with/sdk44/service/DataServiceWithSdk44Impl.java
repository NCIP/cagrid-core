package org.cagrid.test.data.with.sdk44.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.4
 * 
 */
public class DataServiceWithSdk44Impl extends DataServiceWithSdk44ImplBase {

	
	public DataServiceWithSdk44Impl() throws RemoteException {
		super();
	}
	
}

