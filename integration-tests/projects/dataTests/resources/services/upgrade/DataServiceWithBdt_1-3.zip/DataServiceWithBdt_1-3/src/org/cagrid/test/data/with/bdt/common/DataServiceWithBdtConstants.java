package org.cagrid.test.data.with.bdt.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.3
 */
public interface DataServiceWithBdtConstants extends DataServiceWithBdtConstantsBase {
	
}
