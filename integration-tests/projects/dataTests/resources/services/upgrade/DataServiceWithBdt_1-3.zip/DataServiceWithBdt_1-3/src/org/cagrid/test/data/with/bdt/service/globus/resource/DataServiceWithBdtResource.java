package org.cagrid.test.data.with.bdt.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this DataServiceWithBdtResource type.
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServiceWithBdtResource extends DataServiceWithBdtResourceBase {

}
