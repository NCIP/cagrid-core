package org.cagrid.test.data.with.bdt.bdt.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServiceWithBdtBulkDataHandlerImpl extends DataServiceWithBdtBulkDataHandlerImplBase {

	
	public DataServiceWithBdtBulkDataHandlerImpl() throws RemoteException {
		super();
	}
	
}

