package org.cagrid.test.data.with.enumeration.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this DataServiceWithEnumerationResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class DataServiceWithEnumerationResource extends DataServiceWithEnumerationResourceBase {

}
