This directory contains a CA to be used for testing, in the ca directory.
It also contains a set of host credentials (localhost_*.pem)
And sets of user credentials and long term proxies. (user*)