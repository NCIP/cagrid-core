<tr class="noCover">
<td class="line">1</td>
<td class="hits"/>
<td class="code">package&nbsp;gov.nih.nci.cagrid.portal.portlet.notification;</td>
</tr>
<tr class="noCover">
<td class="line">2</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">3</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.dao.GridServiceDao;</td>
</tr>
<tr class="noCover">
<td class="line">4</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.dao.NotificationSubscriberDao;</td>
</tr>
<tr class="noCover">
<td class="line">5</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.dao.NotificationSubscriptionDao;</td>
</tr>
<tr class="noCover">
<td class="line">6</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.dao.PortalUserDao;</td>
</tr>
<tr class="noCover">
<td class="line">7</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.GridService;</td>
</tr>
<tr class="noCover">
<td class="line">8</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.NotificationSubscriber;</td>
</tr>
<tr class="noCover">
<td class="line">9</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.NotificationSubscription;</td>
</tr>
<tr class="noCover">
<td class="line">10</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.PortalUser;</td>
</tr>
<tr class="noCover">
<td class="line">11</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.portlet.AjaxViewGenerator;</td>
</tr>
<tr class="noCover">
<td class="line">12</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.portlet.CaGridPortletApplicationException;</td>
</tr>
<tr class="noCover">
<td class="line">13</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.portlet.query.QueryModel;</td>
</tr>
<tr class="noCover">
<td class="line">14</td>
<td class="hits"/>
<td class="code">import&nbsp;org.apache.commons.logging.Log;</td>
</tr>
<tr class="noCover">
<td class="line">15</td>
<td class="hits"/>
<td class="code">import&nbsp;org.apache.commons.logging.LogFactory;</td>
</tr>
<tr class="noCover">
<td class="line">16</td>
<td class="hits"/>
<td class="code">import&nbsp;org.directwebremoting.annotations.Param;</td>
</tr>
<tr class="noCover">
<td class="line">17</td>
<td class="hits"/>
<td class="code">import&nbsp;org.directwebremoting.annotations.RemoteMethod;</td>
</tr>
<tr class="noCover">
<td class="line">18</td>
<td class="hits"/>
<td class="code">import&nbsp;org.directwebremoting.annotations.RemoteProxy;</td>
</tr>
<tr class="noCover">
<td class="line">19</td>
<td class="hits"/>
<td class="code">import&nbsp;org.directwebremoting.spring.SpringCreator;</td>
</tr>
<tr class="noCover">
<td class="line">20</td>
<td class="hits"/>
<td class="code">import&nbsp;org.springframework.transaction.annotation.Transactional;</td>
</tr>
<tr class="noCover">
<td class="line">21</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">22</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">23</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;User:&nbsp;kherm</td>
</tr>
<tr class="noCover">
<td class="line">24</td>
<td class="hits"/>
<td class="code">&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">25</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;@author&nbsp;kherm&nbsp;manav.kher@semanticbits.com</td>
</tr>
<tr class="noCover">
<td class="line">26</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">27</td>
<td class="hits"/>
<td class="code">@RemoteProxy(name&nbsp;=&nbsp;"NotificationSubscriptionService",</td>
</tr>
<tr class="noCover">
<td class="line">28</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;creator&nbsp;=&nbsp;SpringCreator.class,</td>
</tr>
<tr class="noCover">
<td class="line">29</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;creatorParams&nbsp;=&nbsp;@Param(name&nbsp;=&nbsp;"beanName",</td>
</tr>
<tr class="noCover">
<td class="line">30</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;value&nbsp;=&nbsp;"notificationSubscriptionService"))</td>
</tr>
<tr class="coverFull">
<td class="line">31</td>
<td class="hits">1</td>
<td class="code">public&nbsp;class&nbsp;NotificationSubscriptionService&nbsp;extends&nbsp;AjaxViewGenerator&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">32</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">33</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;NotificationSubscriptionDao&nbsp;notificationSubscriptionDao;</td>
</tr>
<tr class="noCover">
<td class="line">34</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;NotificationSubscriberDao&nbsp;notificationSubscriberDao;</td>
</tr>
<tr class="noCover">
<td class="line">35</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;GridServiceDao&nbsp;gridServiceDao;</td>
</tr>
<tr class="noCover">
<td class="line">36</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;PortalUserDao&nbsp;portalUserDao;</td>
</tr>
<tr class="coverFull">
<td class="line">37</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;static&nbsp;final&nbsp;Log&nbsp;logger&nbsp;=&nbsp;LogFactory.getLog(NotificationSubscriptionService.class);</td>
</tr>
<tr class="noCover">
<td class="line">38</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;QueryModel&nbsp;queryModel;</td>
</tr>
<tr class="noCover">
<td class="line">39</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">40</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">41</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/**</td>
</tr>
<tr class="noCover">
<td class="line">42</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;Will&nbsp;subscribe&nbsp;a&nbsp;user&nbsp;to&nbsp;the&nbsp;service&nbsp;for&nbsp;notifications.</td>
</tr>
<tr class="noCover">
<td class="line">43</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;If&nbsp;user&nbsp;is&nbsp;already&nbsp;subscribed,&nbsp;then&nbsp;it&nbsp;will&nbsp;unsubscribe&nbsp;the&nbsp;user</td>
</tr>
<tr class="noCover">
<td class="line">44</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">45</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;@RemoteMethod</td>
</tr>
<tr class="noCover">
<td class="line">46</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;@Transactional</td>
</tr>
<tr class="noCover">
<td class="line">47</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;boolean&nbsp;subscribreUnsubscribe(int&nbsp;serviceId)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">48</td>
<td class="hits">3</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NotificationSubscription&nbsp;sub&nbsp;=&nbsp;loadSubscription(serviceId);</td>
</tr>
<tr class="coverFull">
<td class="line">49</td>
<td class="hits">3</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(sub&nbsp;!=&nbsp;null)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">50</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;notificationSubscriptionDao.delete(sub);</td>
</tr>
<tr class="coverFull">
<td class="line">51</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.debug("Unsubscribed&nbsp;user&nbsp;from&nbsp;service&nbsp;"&nbsp;+&nbsp;serviceId);</td>
</tr>
<tr class="coverFull">
<td class="line">52</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;false;</td>
</tr>
<tr class="noCover">
<td class="line">53</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">54</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.debug("Creating&nbsp;new&nbsp;subscription&nbsp;for&nbsp;service&nbsp;with&nbsp;id&nbsp;"&nbsp;+&nbsp;serviceId);</td>
</tr>
<tr class="coverFull">
<td class="line">55</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sub&nbsp;=&nbsp;new&nbsp;NotificationSubscription();</td>
</tr>
<tr class="coverFull">
<td class="line">56</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sub.setService(gridServiceDao.getById(serviceId));</td>
</tr>
<tr class="coverFull">
<td class="line">57</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NotificationSubscriber&nbsp;subsc&nbsp;=&nbsp;getPortalUser().getSubscriber();</td>
</tr>
<tr class="coverFull">
<td class="line">58</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(subsc&nbsp;==&nbsp;null)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">59</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;subsc&nbsp;=&nbsp;new&nbsp;NotificationSubscriber();</td>
</tr>
<tr class="coverFull">
<td class="line">60</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;subsc.setPortalUser(getPortalUser());</td>
</tr>
<tr class="coverFull">
<td class="line">61</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;notificationSubscriberDao.save(subsc);</td>
</tr>
<tr class="noCover">
<td class="line">62</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line">63</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sub.setSubscriber(subsc);</td>
</tr>
<tr class="coverFull">
<td class="line">64</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;notificationSubscriptionDao.save(sub);</td>
</tr>
<tr class="coverFull">
<td class="line">65</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.debug("Subscribed&nbsp;user&nbsp;from&nbsp;service&nbsp;"&nbsp;+&nbsp;serviceId);</td>
</tr>
<tr class="coverFull">
<td class="line">66</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;true;</td>
</tr>
<tr class="noCover">
<td class="line">67</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">68</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">69</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">70</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">71</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;@RemoteMethod</td>
</tr>
<tr class="noCover">
<td class="line">72</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;boolean&nbsp;isSubscribed(int&nbsp;serviceId)&nbsp;throws&nbsp;CaGridPortletApplicationException&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">73</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.debug("Checking&nbsp;subscription&nbsp;for&nbsp;"&nbsp;+&nbsp;serviceId);</td>
</tr>
<tr class="coverFull">
<td class="line">74</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;loadSubscription(serviceId)&nbsp;!=&nbsp;null;</td>
</tr>
<tr class="noCover">
<td class="line">75</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">76</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">77</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">78</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;NotificationSubscription&nbsp;loadSubscription(int&nbsp;serviceId)&nbsp;throws&nbsp;CaGridPortletApplicationException&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">79</td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(getPortalUser()&nbsp;==&nbsp;null)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">80</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.warn("No&nbsp;portal&nbsp;user&nbsp;found.&nbsp;Trying&nbsp;to&nbsp;add&nbsp;notification.&nbsp;Denied!");</td>
</tr>
<tr class="coverNone">
<td class="line">81</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;CaGridPortletApplicationException("Please&nbsp;login&nbsp;first");</td>
</tr>
<tr class="noCover">
<td class="line">82</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line">83</td>
<td class="hits">5</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GridService&nbsp;service&nbsp;=&nbsp;gridServiceDao.getById(serviceId);</td>
</tr>
<tr class="coverFull">
<td class="line">84</td>
<td class="hits">5</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(service&nbsp;==&nbsp;null)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">85</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.warn("No&nbsp;service&nbsp;found.&nbsp;Trying&nbsp;to&nbsp;add&nbsp;notification.&nbsp;Denied!");</td>
</tr>
<tr class="coverNone">
<td class="line">86</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;CaGridPortletApplicationException("Service&nbsp;not&nbsp;found&nbsp;in&nbsp;DB");</td>
</tr>
<tr class="noCover">
<td class="line">87</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">88</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line">89</td>
<td class="hits">5</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;notificationSubscriptionDao.getSubscription(service,&nbsp;getPortalUser());</td>
</tr>
<tr class="noCover">
<td class="line">90</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">91</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">92</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">93</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;NotificationSubscriptionDao&nbsp;getNotificationSubscriptionDao()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">94</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;notificationSubscriptionDao;</td>
</tr>
<tr class="noCover">
<td class="line">95</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">96</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">97</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setNotificationSubscriptionDao(NotificationSubscriptionDao&nbsp;notificationSubscriptionDao)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">98</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.notificationSubscriptionDao&nbsp;=&nbsp;notificationSubscriptionDao;</td>
</tr>
<tr class="coverFull">
<td class="line">99</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">100</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">101</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;PortalUser&nbsp;getPortalUser()&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">102</td>
<td class="hits">14</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(queryModel.getPortalUser()&nbsp;!=&nbsp;null)</td>
</tr>
<tr class="coverFull">
<td class="line">103</td>
<td class="hits">13</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;portalUserDao.getById(queryModel.getPortalUser().getId());</td>
</tr>
<tr class="coverNone">
<td class="line">104</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;null;</td>
</tr>
<tr class="noCover">
<td class="line">105</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">106</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">107</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">108</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;GridServiceDao&nbsp;getGridServiceDao()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">109</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;gridServiceDao;</td>
</tr>
<tr class="noCover">
<td class="line">110</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">111</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">112</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setGridServiceDao(GridServiceDao&nbsp;gridServiceDao)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">113</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.gridServiceDao&nbsp;=&nbsp;gridServiceDao;</td>
</tr>
<tr class="coverFull">
<td class="line">114</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">115</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">116</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;NotificationSubscriberDao&nbsp;getNotificationSubscriberDao()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">117</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;notificationSubscriberDao;</td>
</tr>
<tr class="noCover">
<td class="line">118</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">119</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">120</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setNotificationSubscriberDao(NotificationSubscriberDao&nbsp;notificationSubscriberDao)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">121</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.notificationSubscriberDao&nbsp;=&nbsp;notificationSubscriberDao;</td>
</tr>
<tr class="coverFull">
<td class="line">122</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">123</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">124</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;QueryModel&nbsp;getQueryModel()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">125</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;queryModel;</td>
</tr>
<tr class="noCover">
<td class="line">126</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">127</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">128</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setQueryModel(QueryModel&nbsp;queryModel)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">129</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.queryModel&nbsp;=&nbsp;queryModel;</td>
</tr>
<tr class="coverFull">
<td class="line">130</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">131</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">132</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;PortalUserDao&nbsp;getPortalUserDao()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">133</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;portalUserDao;</td>
</tr>
<tr class="noCover">
<td class="line">134</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">135</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">136</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setPortalUserDao(PortalUserDao&nbsp;portalUserDao)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">137</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.portalUserDao&nbsp;=&nbsp;portalUserDao;</td>
</tr>
<tr class="coverFull">
<td class="line">138</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">139</td>
<td class="hits"/>
<td class="code">}</td>
</tr>
