<tr class="noCover">
<td class="line">1</td>
<td class="hits"/>
<td class="code">package&nbsp;gov.nih.nci.cagrid.portal.portlet.query.builder;</td>
</tr>
<tr class="noCover">
<td class="line">2</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">3</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.metadata.dataservice.UMLClass;</td>
</tr>
<tr class="noCover">
<td class="line">4</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.dao.UMLClassDao;</td>
</tr>
<tr class="noCover">
<td class="line">5</td>
<td class="hits"/>
<td class="code">import&nbsp;org.springframework.beans.factory.annotation.Required;</td>
</tr>
<tr class="noCover">
<td class="line">6</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">7</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">8</td>
<td class="hits"/>
<td class="code">import&nbsp;java.util.List;</td>
</tr>
<tr class="noCover">
<td class="line">9</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">10</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">11</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;User:&nbsp;kherm</td>
</tr>
<tr class="noCover">
<td class="line">12</td>
<td class="hits"/>
<td class="code">&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">13</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;@author&nbsp;kherm&nbsp;manav.kher@semanticbits.com</td>
</tr>
<tr class="noCover">
<td class="line">14</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line">15</td>
<td class="hits">0</td>
<td class="code">public&nbsp;class&nbsp;AssociationBasedForeignTargetsProvider&nbsp;implements&nbsp;ForeignTargetsProvider&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">16</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">17</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;UMLClassDao&nbsp;umlClassDao;</td>
</tr>
<tr class="noCover">
<td class="line">18</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">19</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;List&lt;UMLClass&gt;&nbsp;getSemanticallyEquivalentClasses(UMLClass&nbsp;uClass)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">20</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;getUmlClassDao().getSemanticallyEquivalentClassesBasedOnAssociations(uClass);</td>
</tr>
<tr class="noCover">
<td class="line">21</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">22</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">23</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;UMLClassDao&nbsp;getUmlClassDao()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">24</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;umlClassDao;</td>
</tr>
<tr class="noCover">
<td class="line">25</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">26</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">27</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;@Required</td>
</tr>
<tr class="noCover">
<td class="line">28</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setUmlClassDao(UMLClassDao&nbsp;umlClassDao)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">29</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.umlClassDao&nbsp;=&nbsp;umlClassDao;</td>
</tr>
<tr class="coverNone">
<td class="line">30</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">31</td>
<td class="hits"/>
<td class="code">}</td>
</tr>
