<tr class="noCover">
<td class="line">1</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">2</td>
<td class="hits"/>
<td class="code">&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">3</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">4</td>
<td class="hits"/>
<td class="code">package&nbsp;gov.nih.nci.cagrid.portal.portlet.query.cql;</td>
</tr>
<tr class="noCover">
<td class="line">5</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">6</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.dao.QueryInstanceDao;</td>
</tr>
<tr class="noCover">
<td class="line">7</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstance;</td>
</tr>
<tr class="noCover">
<td class="line">8</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.DCQLQueryInstance;</td>
</tr>
<tr class="noCover">
<td class="line">9</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.QueryInstance;</td>
</tr>
<tr class="noCover">
<td class="line">10</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.QueryInstanceState;</td>
</tr>
<tr class="noCover">
<td class="line">11</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.portlet.query.QueryModel;</td>
</tr>
<tr class="noCover">
<td class="line">12</td>
<td class="hits"/>
<td class="code">import&nbsp;org.apache.commons.logging.Log;</td>
</tr>
<tr class="noCover">
<td class="line">13</td>
<td class="hits"/>
<td class="code">import&nbsp;org.apache.commons.logging.LogFactory;</td>
</tr>
<tr class="noCover">
<td class="line">14</td>
<td class="hits"/>
<td class="code">import&nbsp;org.directwebremoting.WebContext;</td>
</tr>
<tr class="noCover">
<td class="line">15</td>
<td class="hits"/>
<td class="code">import&nbsp;org.directwebremoting.WebContextFactory;</td>
</tr>
<tr class="noCover">
<td class="line">16</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">17</td>
<td class="hits"/>
<td class="code">import&nbsp;javax.servlet.http.HttpServletRequest;</td>
</tr>
<tr class="noCover">
<td class="line">18</td>
<td class="hits"/>
<td class="code">import&nbsp;java.util.ArrayList;</td>
</tr>
<tr class="noCover">
<td class="line">19</td>
<td class="hits"/>
<td class="code">import&nbsp;java.util.List;</td>
</tr>
<tr class="noCover">
<td class="line">20</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">21</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">22</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;@author&nbsp;&lt;a&nbsp;href="mailto:joshua.phillips@semanticbits.com"&gt;Joshua&nbsp;Phillips&lt;/a&gt;</td>
</tr>
<tr class="noCover">
<td class="line">23</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">24</td>
<td class="hits"/>
<td class="code">public&nbsp;class&nbsp;CQLQueryHistoryFacade&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">25</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">26</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;static&nbsp;final&nbsp;Log&nbsp;logger&nbsp;=&nbsp;LogFactory</td>
</tr>
<tr class="noCover">
<td class="line">27</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.getLog(CQLQueryHistoryFacade.class);</td>
</tr>
<tr class="noCover">
<td class="line">28</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">29</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;QueryModel&nbsp;queryModel;</td>
</tr>
<tr class="noCover">
<td class="line">30</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;String&nbsp;requestAttributeName;</td>
</tr>
<tr class="noCover">
<td class="line">31</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;String&nbsp;renderServletUrl;</td>
</tr>
<tr class="noCover">
<td class="line">32</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;QueryInstanceDao&nbsp;queryInstanceDao;</td>
</tr>
<tr class="noCover">
<td class="line">33</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">34</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/**</td>
</tr>
<tr class="noCover">
<td class="line">35</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">36</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line">37</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;CQLQueryHistoryFacade()&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">38</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">39</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">40</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">41</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;List&lt;QueryInstance&gt;&nbsp;getActiveInstances()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">42</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;List&lt;QueryInstance&gt;&nbsp;activeInstances&nbsp;=&nbsp;new&nbsp;ArrayList&lt;QueryInstance&gt;();</td>
</tr>
<tr class="coverNone">
<td class="line">43</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;List&lt;QueryInstance&gt;&nbsp;submitted&nbsp;=&nbsp;getQueryModel()</td>
</tr>
<tr class="noCover">
<td class="line">44</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.getSubmittedQueries();</td>
</tr>
<tr class="coverNone">
<td class="line">45</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;for&nbsp;(QueryInstance&nbsp;instance&nbsp;:&nbsp;submitted)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">46</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(isActive(instance))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">47</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;activeInstances.add(instance);</td>
</tr>
<tr class="noCover">
<td class="line">48</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">49</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">50</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;activeInstances;</td>
</tr>
<tr class="noCover">
<td class="line">51</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">52</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">53</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;boolean&nbsp;isActive(QueryInstance&nbsp;instance)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">54</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;instance.getState()&nbsp;==&nbsp;QueryInstanceState.UNSCHEDULED</td>
</tr>
<tr class="noCover">
<td class="line">55</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;instance.getState()&nbsp;==&nbsp;QueryInstanceState.SCHEDULED</td>
</tr>
<tr class="noCover">
<td class="line">56</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;instance.getState()&nbsp;==&nbsp;QueryInstanceState.RUNNING;</td>
</tr>
<tr class="noCover">
<td class="line">57</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">58</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">59</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;QueryInstance&nbsp;getInstance(Integer&nbsp;instanceId)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">60</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">61</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;QueryInstance&nbsp;instance&nbsp;=&nbsp;null;</td>
</tr>
<tr class="coverNone">
<td class="line">62</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;List&lt;QueryInstance&gt;&nbsp;submitted&nbsp;=&nbsp;getQueryModel()</td>
</tr>
<tr class="noCover">
<td class="line">63</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.getSubmittedQueries();</td>
</tr>
<tr class="noCover">
<td class="line">64</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">65</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;for&nbsp;(QueryInstance&nbsp;inst&nbsp;:&nbsp;submitted)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">66</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(inst.getId().equals(instanceId)){</td>
</tr>
<tr class="coverNone">
<td class="line">67</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance&nbsp;=&nbsp;inst;</td>
</tr>
<tr class="coverNone">
<td class="line">68</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line">69</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">70</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">71</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">72</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(instance&nbsp;!=&nbsp;null)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">73</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//Refresh&nbsp;the&nbsp;object&nbsp;so&nbsp;that&nbsp;it&nbsp;shows&nbsp;correct&nbsp;state.</td>
</tr>
<tr class="coverNone">
<td class="line">74</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String&nbsp;result&nbsp;=&nbsp;instance.getResult();</td>
</tr>
<tr class="coverNone">
<td class="line">75</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance&nbsp;=&nbsp;getQueryInstanceDao().getById(instanceId);</td>
</tr>
<tr class="coverNone">
<td class="line">76</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setResult(result);</td>
</tr>
<tr class="noCover">
<td class="line">77</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">78</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">79</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(instance&nbsp;==&nbsp;null)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">80</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance&nbsp;=&nbsp;getQueryInstanceDao().getById(instanceId);</td>
</tr>
<tr class="noCover">
<td class="line">81</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">82</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;instance;</td>
</tr>
<tr class="noCover">
<td class="line">83</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">84</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line">85</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;String&nbsp;renderCQLInstance(CQLQueryInstance&nbsp;bean,&nbsp;String&nbsp;namespace)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">86</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;renderInstance(bean,&nbsp;namespace);</td>
</tr>
<tr class="noCover">
<td class="line">87</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">88</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line">89</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;String&nbsp;renderDCQLInstance(DCQLQueryInstance&nbsp;bean,&nbsp;String&nbsp;namespace)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">90</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;renderInstance(bean,&nbsp;namespace);</td>
</tr>
<tr class="noCover">
<td class="line">91</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">92</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">93</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;String&nbsp;renderInstance(QueryInstance&nbsp;bean,&nbsp;String&nbsp;namespace)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">94</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">95</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String&nbsp;html&nbsp;=&nbsp;null;</td>
</tr>
<tr class="noCover">
<td class="line">96</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">97</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;QueryInstance&nbsp;instance&nbsp;=&nbsp;getQueryInstanceDao().getById(bean.getId());</td>
</tr>
<tr class="coverNone">
<td class="line">98</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(instance&nbsp;!=&nbsp;null)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">99</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;for&nbsp;(QueryInstance&nbsp;inst&nbsp;:&nbsp;getQueryModel().getSubmittedQueries())&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">100</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(inst.getId().equals(instance.getId()))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">101</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setResult(inst.getResult());</td>
</tr>
<tr class="noCover">
<td class="line">102</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">103</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">104</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">105</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">106</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WebContext&nbsp;webContext&nbsp;=&nbsp;WebContextFactory.get();</td>
</tr>
<tr class="coverNone">
<td class="line">107</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;HttpServletRequest&nbsp;request&nbsp;=&nbsp;webContext.getHttpServletRequest();</td>
</tr>
<tr class="coverNone">
<td class="line">108</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;request.setAttribute(getRequestAttributeName(),&nbsp;instance);</td>
</tr>
<tr class="coverNone">
<td class="line">109</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;request.setAttribute("namespace",&nbsp;namespace);</td>
</tr>
<tr class="noCover">
<td class="line">110</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;try&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">111</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;html&nbsp;=&nbsp;webContext.forwardToString(getRenderServletUrl());</td>
</tr>
<tr class="coverNone">
<td class="line">112</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;catch&nbsp;(Exception&nbsp;ex)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">113</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String&nbsp;msg&nbsp;=&nbsp;"Error&nbsp;rendering&nbsp;QueryInstance:&nbsp;"&nbsp;+&nbsp;ex.getMessage();</td>
</tr>
<tr class="coverNone">
<td class="line">114</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.error(msg,&nbsp;ex);</td>
</tr>
<tr class="coverNone">
<td class="line">115</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;RuntimeException(msg,&nbsp;ex);</td>
</tr>
<tr class="coverNone">
<td class="line">116</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">117</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">118</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;html;</td>
</tr>
<tr class="noCover">
<td class="line">119</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">120</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">121</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;String&nbsp;getRequestAttributeName()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">122</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;requestAttributeName;</td>
</tr>
<tr class="noCover">
<td class="line">123</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">124</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">125</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setRequestAttributeName(String&nbsp;requestAttributeName)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">126</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.requestAttributeName&nbsp;=&nbsp;requestAttributeName;</td>
</tr>
<tr class="coverNone">
<td class="line">127</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">128</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">129</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;String&nbsp;getRenderServletUrl()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">130</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;renderServletUrl;</td>
</tr>
<tr class="noCover">
<td class="line">131</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">132</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">133</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setRenderServletUrl(String&nbsp;renderServletUrl)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">134</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.renderServletUrl&nbsp;=&nbsp;renderServletUrl;</td>
</tr>
<tr class="coverNone">
<td class="line">135</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">136</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">137</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;QueryInstanceDao&nbsp;getQueryInstanceDao()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">138</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;queryInstanceDao;</td>
</tr>
<tr class="noCover">
<td class="line">139</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">140</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">141</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setQueryInstanceDao(QueryInstanceDao&nbsp;queryInstanceDao)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">142</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.queryInstanceDao&nbsp;=&nbsp;queryInstanceDao;</td>
</tr>
<tr class="coverNone">
<td class="line">143</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">144</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">145</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;QueryModel&nbsp;getQueryModel()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">146</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;queryModel;</td>
</tr>
<tr class="noCover">
<td class="line">147</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">148</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">149</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setQueryModel(QueryModel&nbsp;queryModel)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">150</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.queryModel&nbsp;=&nbsp;queryModel;</td>
</tr>
<tr class="coverNone">
<td class="line">151</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">152</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">153</td>
<td class="hits"/>
<td class="code">}</td>
</tr>
