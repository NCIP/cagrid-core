<tr class="noCover">
<td class="line">1</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">2</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line">3</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">4</td>
<td class="hits"/>
<td class="code">package&nbsp;gov.nih.nci.cagrid.portal.portlet.query.results;</td>
</tr>
<tr class="noCover">
<td class="line">5</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">6</td>
<td class="hits"/>
<td class="code">import&nbsp;java.util.ArrayList;</td>
</tr>
<tr class="noCover">
<td class="line">7</td>
<td class="hits"/>
<td class="code">import&nbsp;java.util.List;</td>
</tr>
<tr class="noCover">
<td class="line">8</td>
<td class="hits"/>
<td class="code">import&nbsp;java.util.Stack;</td>
</tr>
<tr class="noCover">
<td class="line">9</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">10</td>
<td class="hits"/>
<td class="code">import&nbsp;org.xml.sax.Attributes;</td>
</tr>
<tr class="noCover">
<td class="line">11</td>
<td class="hits"/>
<td class="code">import&nbsp;org.xml.sax.helpers.DefaultHandler;</td>
</tr>
<tr class="noCover">
<td class="line">12</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">13</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">14</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;@author&nbsp;&lt;a&nbsp;href="mailto:joshua.phillips@semanticbits.com"&gt;Joshua&nbsp;Phillips&lt;/a&gt;</td>
</tr>
<tr class="noCover">
<td class="line">15</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line">16</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="coverFull">
<td class="line">17</td>
<td class="hits">1</td>
<td class="code">public&nbsp;abstract&nbsp;class&nbsp;BaseQueryResultHandler&nbsp;extends&nbsp;DefaultHandler&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">18</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line">19</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;Stack&lt;ElementInfo&gt;&nbsp;elementStack&nbsp;=&nbsp;new&nbsp;Stack&lt;ElementInfo&gt;();</td>
</tr>
<tr class="noCover">
<td class="line">20</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;ResultType&nbsp;resultType;</td>
</tr>
<tr class="noCover">
<td class="line">21</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;QueryType&nbsp;queryType;</td>
</tr>
<tr class="coverFull">
<td class="line">22</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;List&lt;String&gt;&nbsp;columnNames&nbsp;=&nbsp;new&nbsp;ArrayList&lt;String&gt;();</td>
</tr>
<tr class="noCover">
<td class="line">23</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line">24</td>
<td class="hits">5</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;enum&nbsp;ResultType&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">25</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;EMPTY,&nbsp;OBJECT,&nbsp;ATTRIBUTE,&nbsp;COUNT;</td>
</tr>
<tr class="noCover">
<td class="line">26</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">27</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line">28</td>
<td class="hits">3</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;enum&nbsp;QueryType&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">29</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CQL,&nbsp;DCQL;</td>
</tr>
<tr class="noCover">
<td class="line">30</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">31</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line">32</td>
<td class="hits">1</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;class&nbsp;ElementInfo&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">33</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String&nbsp;uri;</td>
</tr>
<tr class="noCover">
<td class="line">34</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String&nbsp;localName;</td>
</tr>
<tr class="noCover">
<td class="line">35</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String&nbsp;qName;</td>
</tr>
<tr class="noCover">
<td class="line">36</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Attributes&nbsp;atts;</td>
</tr>
<tr class="noCover">
<td class="line">37</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line">38</td>
<td class="hits">181</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ElementInfo(String&nbsp;uri,&nbsp;String&nbsp;localName,&nbsp;String&nbsp;qName,&nbsp;Attributes&nbsp;atts)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">39</td>
<td class="hits">181</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.uri&nbsp;=&nbsp;uri;</td>
</tr>
<tr class="coverFull">
<td class="line">40</td>
<td class="hits">181</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.localName&nbsp;=&nbsp;localName;</td>
</tr>
<tr class="coverFull">
<td class="line">41</td>
<td class="hits">181</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.qName&nbsp;=&nbsp;qName;</td>
</tr>
<tr class="coverFull">
<td class="line">42</td>
<td class="hits">181</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.atts&nbsp;=&nbsp;atts;</td>
</tr>
<tr class="coverFull">
<td class="line">43</td>
<td class="hits">181</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">44</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">45</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">46</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;List&lt;String&gt;&nbsp;getColumnNames()&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">47</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;columnNames;</td>
</tr>
<tr class="noCover">
<td class="line">48</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">49</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">50</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setColumnNames(List&lt;String&gt;&nbsp;columnNames)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">51</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.columnNames&nbsp;=&nbsp;columnNames;</td>
</tr>
<tr class="coverNone">
<td class="line">52</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">53</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">54</td>
<td class="hits"/>
<td class="code">}</td>
</tr>
