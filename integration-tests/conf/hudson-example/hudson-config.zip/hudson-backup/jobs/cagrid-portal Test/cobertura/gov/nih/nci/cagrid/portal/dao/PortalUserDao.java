<tr class="noCover">
<td class="line">1</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">2</td>
<td class="hits"/>
<td class="code">&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">3</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">4</td>
<td class="hits"/>
<td class="code">package&nbsp;gov.nih.nci.cagrid.portal.dao;</td>
</tr>
<tr class="noCover">
<td class="line">5</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">6</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.PortalUser;</td>
</tr>
<tr class="noCover">
<td class="line">7</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">8</td>
<td class="hits"/>
<td class="code">import&nbsp;javax.persistence.NonUniqueResultException;</td>
</tr>
<tr class="noCover">
<td class="line">9</td>
<td class="hits"/>
<td class="code">import&nbsp;java.util.List;</td>
</tr>
<tr class="noCover">
<td class="line">10</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">11</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">12</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;@author&nbsp;&lt;a&nbsp;href="joshua.phillips@semanticbits.com"&gt;Joshua&nbsp;Phillips&lt;/a&gt;</td>
</tr>
<tr class="noCover">
<td class="line">13</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="coverFull">
<td class="line">14</td>
<td class="hits">35</td>
<td class="code">public&nbsp;class&nbsp;PortalUserDao&nbsp;extends&nbsp;AbstractDao&lt;PortalUser&gt;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">15</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">16</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;(non-Javadoc)</td>
</tr>
<tr class="noCover">
<td class="line">17</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;@see&nbsp;gov.nih.nci.cagrid.portal.dao.AbstractDao#domainClass()</td>
</tr>
<tr class="noCover">
<td class="line">18</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">19</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;@Override</td>
</tr>
<tr class="noCover">
<td class="line">20</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;Class&nbsp;domainClass()&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">21</td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;PortalUser.class;</td>
</tr>
<tr class="noCover">
<td class="line">22</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">23</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">24</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;@Override</td>
</tr>
<tr class="noCover">
<td class="line">25</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;save(PortalUser&nbsp;domainObject)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line">26</td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;super.save(domainObject);&nbsp;&nbsp;&nbsp;&nbsp;//To&nbsp;change&nbsp;body&nbsp;of&nbsp;overridden&nbsp;methods&nbsp;use&nbsp;File&nbsp;|&nbsp;Settings&nbsp;|&nbsp;File&nbsp;Templates.</td>
</tr>
<tr class="coverFull">
<td class="line">27</td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">28</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">29</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;PortalUser&nbsp;getByPortalId(String&nbsp;userId)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">30</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;try&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">31</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String[]&nbsp;parts&nbsp;=&nbsp;userId.split(":");</td>
</tr>
<tr class="coverNone">
<td class="line">32</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Long.valueOf(parts[0]);</td>
</tr>
<tr class="coverNone">
<td class="line">33</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Long.valueOf(parts[1]);</td>
</tr>
<tr class="coverNone">
<td class="line">34</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;catch&nbsp;(Exception&nbsp;ex)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">35</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;RuntimeException("Invalid&nbsp;portal&nbsp;ID:&nbsp;"&nbsp;+&nbsp;userId);</td>
</tr>
<tr class="coverNone">
<td class="line">36</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">37</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PortalUser&nbsp;user&nbsp;=&nbsp;null;</td>
</tr>
<tr class="coverNone">
<td class="line">38</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;List&nbsp;l&nbsp;=&nbsp;getHibernateTemplate().find("from&nbsp;PortalUser&nbsp;where&nbsp;portalId&nbsp;=&nbsp;?",&nbsp;userId);</td>
</tr>
<tr class="coverNone">
<td class="line">39</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(l.size()&nbsp;&gt;&nbsp;1)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">40</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;NonUniqueResultException("More&nbsp;than&nbsp;one&nbsp;PortalUser&nbsp;found&nbsp;for&nbsp;portalId&nbsp;=&nbsp;"&nbsp;+&nbsp;userId);</td>
</tr>
<tr class="noCover">
<td class="line">41</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">42</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(l.size()&nbsp;==&nbsp;1)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">43</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;user&nbsp;=&nbsp;(PortalUser)&nbsp;l.iterator().next();</td>
</tr>
<tr class="noCover">
<td class="line">44</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">45</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;user;</td>
</tr>
<tr class="noCover">
<td class="line">46</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">47</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">48</td>
<td class="hits"/>
<td class="code">}</td>
</tr>
