<tr class="noCover">
<td class="line">1</td>
<td class="hits"/>
<td class="code">package&nbsp;gov.nih.nci.cagrid.portal.portlet.query.dcql;</td>
</tr>
<tr class="noCover">
<td class="line">2</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">3</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.dao.DCQLQueryInstanceDao;</td>
</tr>
<tr class="noCover">
<td class="line">4</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.DCQLQueryInstance;</td>
</tr>
<tr class="noCover">
<td class="line">5</td>
<td class="hits"/>
<td class="code">import&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.QueryInstanceState;</td>
</tr>
<tr class="noCover">
<td class="line">6</td>
<td class="hits"/>
<td class="code">import&nbsp;org.apache.commons.logging.Log;</td>
</tr>
<tr class="noCover">
<td class="line">7</td>
<td class="hits"/>
<td class="code">import&nbsp;org.apache.commons.logging.LogFactory;</td>
</tr>
<tr class="noCover">
<td class="line">8</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">9</td>
<td class="hits"/>
<td class="code">import&nbsp;java.io.PrintWriter;</td>
</tr>
<tr class="noCover">
<td class="line">10</td>
<td class="hits"/>
<td class="code">import&nbsp;java.io.StringWriter;</td>
</tr>
<tr class="noCover">
<td class="line">11</td>
<td class="hits"/>
<td class="code">import&nbsp;java.util.Date;</td>
</tr>
<tr class="noCover">
<td class="line">12</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">13</td>
<td class="hits"/>
<td class="code">/**</td>
</tr>
<tr class="noCover">
<td class="line">14</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;User:&nbsp;kherm</td>
</tr>
<tr class="noCover">
<td class="line">15</td>
<td class="hits"/>
<td class="code">&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">16</td>
<td class="hits"/>
<td class="code">&nbsp;*&nbsp;@author&nbsp;kherm&nbsp;manav.kher@semanticbits.com</td>
</tr>
<tr class="noCover">
<td class="line">17</td>
<td class="hits"/>
<td class="code">&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">18</td>
<td class="hits"/>
<td class="code">public&nbsp;class&nbsp;DefaultDCQLQueryInstanceListener&nbsp;implements&nbsp;DCQLQueryInstanceListener&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">19</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">20</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;static&nbsp;final&nbsp;Log&nbsp;logger&nbsp;=&nbsp;LogFactory</td>
</tr>
<tr class="noCover">
<td class="line">21</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.getLog(DefaultDCQLQueryInstanceListener.class);</td>
</tr>
<tr class="noCover">
<td class="line">22</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">23</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;DCQLQueryInstanceDao&nbsp;dcqlQueryInstanceDao;</td>
</tr>
<tr class="noCover">
<td class="line">24</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">25</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/**</td>
</tr>
<tr class="noCover">
<td class="line">26</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">27</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line">28</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;DefaultDCQLQueryInstanceListener()&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line">29</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line">30</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">31</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">32</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;onCancelled(DCQLQueryInstance&nbsp;instance,&nbsp;boolean&nbsp;cancelled)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">33</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!cancelled)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">34</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.warn("Couldn't&nbsp;cancel&nbsp;DCQLQueryInstance:"&nbsp;+&nbsp;instance.getId());</td>
</tr>
<tr class="noCover">
<td class="line">35</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">36</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setState(QueryInstanceState.CANCELLED);</td>
</tr>
<tr class="coverNone">
<td class="line">37</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;getDcqlQueryInstanceDao().save(instance);</td>
</tr>
<tr class="noCover">
<td class="line">38</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">39</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">40</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">41</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;onTimeout(DCQLQueryInstance&nbsp;instance,&nbsp;boolean&nbsp;cancelled)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">42</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!cancelled)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">43</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.warn("Couldn't&nbsp;cancel&nbsp;DCQLQueryInstance:"&nbsp;+&nbsp;instance.getId());</td>
</tr>
<tr class="noCover">
<td class="line">44</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">45</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setState(QueryInstanceState.TIMEDOUT);</td>
</tr>
<tr class="coverNone">
<td class="line">46</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;getDcqlQueryInstanceDao().save(instance);</td>
</tr>
<tr class="noCover">
<td class="line">47</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">48</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">49</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">50</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*</td>
</tr>
<tr class="noCover">
<td class="line">51</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;(non-Javadoc)</td>
</tr>
<tr class="noCover">
<td class="line">52</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">53</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;@see&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstanceListener#onComplete(gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstance,</td>
</tr>
<tr class="noCover">
<td class="line">54</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;java.lang.String)</td>
</tr>
<tr class="noCover">
<td class="line">55</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">56</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;onComplete(DCQLQueryInstance&nbsp;instance,&nbsp;String&nbsp;results)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">57</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!QueryInstanceState.CANCELLED.equals(instance.getState()))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">58</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setFinishTime(new&nbsp;Date());</td>
</tr>
<tr class="coverNone">
<td class="line">59</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setState(QueryInstanceState.COMPLETE);</td>
</tr>
<tr class="coverNone">
<td class="line">60</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;getDcqlQueryInstanceDao().save(instance);</td>
</tr>
<tr class="coverNone">
<td class="line">61</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setResult(results);</td>
</tr>
<tr class="noCover">
<td class="line">62</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">63</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">64</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">65</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*</td>
</tr>
<tr class="noCover">
<td class="line">66</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;(non-Javadoc)</td>
</tr>
<tr class="noCover">
<td class="line">67</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">68</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;@see&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstanceListener#onError(gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstance,</td>
</tr>
<tr class="noCover">
<td class="line">69</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;java.lang.Exception)</td>
</tr>
<tr class="noCover">
<td class="line">70</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">71</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;onError(DCQLQueryInstance&nbsp;instance,&nbsp;Exception&nbsp;error)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">72</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!QueryInstanceState.CANCELLED.equals(instance.getState()))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">73</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String&nbsp;msg&nbsp;=&nbsp;error.getMessage();</td>
</tr>
<tr class="coverNone">
<td class="line">74</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logger.info("DCQLQueryInstance:"&nbsp;+&nbsp;instance.getId()</td>
</tr>
<tr class="noCover">
<td class="line">75</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+&nbsp;"&nbsp;encountered&nbsp;error:&nbsp;"&nbsp;+&nbsp;msg,&nbsp;error);</td>
</tr>
<tr class="coverNone">
<td class="line">76</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;StringWriter&nbsp;w&nbsp;=&nbsp;new&nbsp;StringWriter();</td>
</tr>
<tr class="coverNone">
<td class="line">77</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;error.printStackTrace(new&nbsp;PrintWriter(w));</td>
</tr>
<tr class="coverNone">
<td class="line">78</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setError(w.getBuffer().toString());</td>
</tr>
<tr class="coverNone">
<td class="line">79</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setState(QueryInstanceState.ERROR);</td>
</tr>
<tr class="coverNone">
<td class="line">80</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;getDcqlQueryInstanceDao().save(instance);</td>
</tr>
<tr class="noCover">
<td class="line">81</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line">82</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">83</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">84</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*</td>
</tr>
<tr class="noCover">
<td class="line">85</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;(non-Javadoc)</td>
</tr>
<tr class="noCover">
<td class="line">86</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">87</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;@see&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstanceListener#onRunning(gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstance)</td>
</tr>
<tr class="noCover">
<td class="line">88</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">89</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;onRunning(DCQLQueryInstance&nbsp;instance)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">90</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setState(QueryInstanceState.RUNNING);</td>
</tr>
<tr class="coverNone">
<td class="line">91</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setStartTime(new&nbsp;Date());</td>
</tr>
<tr class="coverNone">
<td class="line">92</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;getDcqlQueryInstanceDao().save(instance);</td>
</tr>
<tr class="coverNone">
<td class="line">93</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">94</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">95</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*</td>
</tr>
<tr class="noCover">
<td class="line">96</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;(non-Javadoc)</td>
</tr>
<tr class="noCover">
<td class="line">97</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*</td>
</tr>
<tr class="noCover">
<td class="line">98</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;@see&nbsp;gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstanceListener#onSheduled(gov.nih.nci.cagrid.portal.domain.dataservice.CQLQueryInstance)</td>
</tr>
<tr class="noCover">
<td class="line">99</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line">100</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;onSheduled(DCQLQueryInstance&nbsp;instance)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">101</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instance.setState(QueryInstanceState.SCHEDULED);</td>
</tr>
<tr class="coverNone">
<td class="line">102</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;getDcqlQueryInstanceDao().save(instance);</td>
</tr>
<tr class="coverNone">
<td class="line">103</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">104</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">105</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;DCQLQueryInstanceDao&nbsp;getDcqlQueryInstanceDao()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">106</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;dcqlQueryInstanceDao;</td>
</tr>
<tr class="noCover">
<td class="line">107</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">108</td>
<td class="hits"/>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line">109</td>
<td class="hits"/>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;void&nbsp;setDcqlQueryInstanceDao(DCQLQueryInstanceDao&nbsp;dcqlQueryInstanceDao)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line">110</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;this.dcqlQueryInstanceDao&nbsp;=&nbsp;dcqlQueryInstanceDao;</td>
</tr>
<tr class="coverNone">
<td class="line">111</td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line">112</td>
<td class="hits"/>
<td class="code">}</td>
</tr>
